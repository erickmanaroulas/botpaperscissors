//
//  CameraPreview.swift
//  Bot Paper Scissors
//
//  Created by Erick Manaroulas Felipe on 18/04/22.
//

import UIKit
import AVFoundation

final class CameraPreview: UIView {

    override class var layerClass: AnyClass {
        AVCaptureVideoPreviewLayer.self
    }

    var previewLayer: AVCaptureVideoPreviewLayer {
        layer as! AVCaptureVideoPreviewLayer
    }
}
