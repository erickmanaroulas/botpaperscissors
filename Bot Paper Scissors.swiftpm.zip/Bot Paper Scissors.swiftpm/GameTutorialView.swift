//
//  GameTutorialView.swift
//  Bot Paper Scissors
//
//  Created by Erick Manaroulas Felipe on 22/04/22.
//

import SwiftUI

struct GameTutorialView: View , ComputerScreenDelegate {
    func didFinishDisplayingAllText() {
        didFinishText = true
    }

    @State var didFinishText: Bool = false

    var body: some View {
        VStack {
            ComputerScreenView(texts: ["Now we are ready to play", "Make your sign before the countdown ends", "I will make my sign as soon as it ends.", "Don't worry, I won't cheat ;)", "First that wins 3 rounds wins the game, deal?"], delegate: self)
            NavigationLink {
                GameView()
            } label: {
                Image(systemName: "play.fill")
                    .foregroundColor(.primary)
                    .padding()
                    .padding(.horizontal, 100)
                    .background(Color.accentColor)
                    .cornerRadius(90)
            }.disabled(!didFinishText)
        }
    }

}

struct GameTutorialView_Previews: PreviewProvider {
    static var previews: some View {
        GameTutorialView()
    }
}
