//
//  File.swift
//  Bot Paper Scissors
//
//  Created by Erick Manaroulas Felipe on 24/04/22.
//

Please play in portrait mode!
