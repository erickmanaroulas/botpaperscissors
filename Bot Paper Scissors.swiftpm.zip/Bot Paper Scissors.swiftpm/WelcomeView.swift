//
//  WelcomeView.swift
//  Bot Paper Scissors
//
//  Created by Erick Manaroulas Felipe on 18/04/22.
//

import SwiftUI

struct WelcomeView: View {
    @ObservedObject var gameManager = GameManager.shared

    var body: some View {
        Text(gameManager.welcomeText)
    }
}

struct WelcomeView_Previews: PreviewProvider {
    static var previews: some View {
        WelcomeView()
    }
}
