//
//  HandPose.swift
//  Bot Paper Scissors
//
//  Created by Erick Manaroulas Felipe on 20/04/22.
//

import Foundation
import SwiftUI

enum GameResult {
    case victory
    case loss
    case draw
    case undefined

    var displayString: String {
        switch self {
        case .victory:
            return "You Won 🎉"
        case .loss:
            return "You Lost 😕"
        case .draw:
            return "Draw "
        case .undefined:
            return "Not sure 🤔"
        }
    }

    var color: Color {
        switch self {
        case .victory:
            return .green
        case .loss:
            return .red
        case .draw, .undefined:
            return .yellow
        }
    }
}

enum HandPose: String, CaseIterable {
    case rock = "rock"
    case paper = "paper"
    case scissors = "scissors"
    case undefined = "not sure"

    static var validPoses: [HandPose] { return [.rock, .paper, .scissors] }

    var emoji: String {
        switch self {
        case .rock:
            return "✊"
        case .paper:
            return "🖐"
        case .scissors:
            return "✌️"
        default:
            return "🤔"
        }
    }

    func compare(other: HandPose) -> GameResult {
        switch (self, other) {
        case (.rock, .scissors), (.scissors, .paper), (.paper, .rock):
            return .victory
        default:
            if self == other { return .draw }
            if self == .undefined { return .undefined}
            return .loss
        }
    }

    func equals(other: HandPose) -> GameResult {
        if self == other { return .victory }
        if self == .undefined { return .undefined }
        return .loss
    }

    func losesTo() -> HandPose {
        switch self {
        case .rock:
            return .paper
        case .paper:
            return .scissors
        case .scissors:
            return .rock
        case .undefined:
            return self
        }
    }
}
