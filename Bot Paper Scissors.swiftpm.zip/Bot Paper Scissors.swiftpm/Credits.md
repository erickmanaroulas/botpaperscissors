//
//  Credits.md
//  Bot Paper Scissors
//
//  Created by Erick Manaroulas Felipe on 24/04/22.
//


Code for CameraViewController was inspired by Raywenderlich and WWDC21 and WWDC20 public code snippets.
Model was trained using my colleagues from the Apple Developer Academy, thans for your -literal- hands!
