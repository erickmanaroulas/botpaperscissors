//
//  CalibrationView.swift
//  Bot Paper Scissors
//
//  Created by Erick Manaroulas Felipe on 22/04/22.
//

import SwiftUI

struct CalibrationView: View {
    @ObservedObject var gameManager = GameManager.shared

    let countdownWaitTime = 3

    @State var circleFillColor: Color = .white
    @State var centerDisplayText: String = ""
    @State var timeLeft: Int = 3
    @State var wins: Int = 0
    @State var didFinishCalibrating = false
    @State var shouldShowAlert = false
    @State var currentPoseIndex: Int = 0
    @State var posesToTest: [HandPose] = [.rock, .scissors, .paper, .scissors, .rock, .scissors]
    @State var poseToMake: HandPose = .paper
    @State var isViewDisplayed: Bool = false
    @State var hasShownAlert = false
    
    var body: some View {
        ZStack {
            VStack{
                Text("You are making a \(gameManager.currentlyReadHandPose.emoji) Try to make a \(poseToMake.emoji) and hold for \(timeLeft) seconds")
                    .padding()
                    .background(Color.primary.opacity(0.2))
                    .cornerRadius(30)
                    .frame(alignment: .topLeading)
                CameraView()
                    .padding()
                    .border(circleFillColor, width: 4)
//                    .alert("Calibration Finished", isPresented: $shouldShowAlert) {
//                        VStack {
//                            Text("Continue testing or tap the button below to play the game!")
//                            Button {
//                                shouldShowAlert = false
//                            } label: {
//                                Text("OK")
//                            }
//                        }
//                    }
                NavigationLink(destination: GameTutorialView(), isActive: $didFinishCalibrating, label: { Text("hi") }).hidden()
            }
            ZStack {
                Circle()
                    .fill(circleFillColor, strokeBorder: .black, lineWidth: 5)
                    .frame(width: 200, height: 200, alignment: .center)
                VStack {
                    Text(centerDisplayText)
                        .fontWeight(.semibold)
                        .font(.largeTitle)
                        .foregroundColor(.black)
                        .onReceive(gameManager.timer) { input in

                            guard isViewDisplayed else { return }

                            if let pose = posesToTest[safeIndex: currentPoseIndex] {
                                gameManager.currentlyDisplayedHandPose = pose
                                poseToMake = pose.losesTo()
                                centerDisplayText = pose.emoji

                                let result = gameManager.currentlyReadHandPose.compare(other: gameManager.currentlyDisplayedHandPose)
                                circleFillColor = result.color

                                if result == .victory {
                                    timeLeft -= 1
                                    if timeLeft == 0 {
                                        currentPoseIndex += 1
                                        if currentPoseIndex + 1 > posesToTest.count {
                                            currentPoseIndex = 0
                                            posesToTest = posesToTest.shuffled()
                                            didFinishCalibrating = true
                                            if !hasShownAlert {
                                                shouldShowAlert = true
                                                hasShownAlert = true
                                            }
                                        }
                                    }
                                } else {
                                    timeLeft = countdownWaitTime
                                }
                            }
                        }
                }
            }
            .onAppear() {
                isViewDisplayed = true
            }
            .onDisappear() {
                isViewDisplayed = false
            }
        }
    }
}


struct CalibrationView_Previews: PreviewProvider {
    static var previews: some View {
        CalibrationView()
    }
}
