//
//  ComputerScreenView.swift
//  Bot Paper Scissors
//
//  Created by Erick Manaroulas Felipe on 24/04/22.
//

import SwiftUI
import AVFoundation

protocol ComputerScreenDelegate {
    func didFinishDisplayingAllText()
}

struct ComputerScreenView: View {
    @State var displayedText: String = ""
    @State var finalText: String = ""
    @State var finalTextIndex: Int = -1
    @State var ticksWithUnderscore: Int = 0
    @State var digits = 0
    @State var displayingUnderscore: Bool = false
    @State var didFinishText: Bool = false

    let texts: [String]
    let delegate: ComputerScreenDelegate
    let maxUnderscoreticks: Int = 5

    let synthesizer = AVSpeechSynthesizer()

    func utteranceFrom(_ string: String) -> AVSpeechUtterance {
        let utterance = AVSpeechUtterance(string: string)
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")

        return utterance
    }

    init(texts: [String], delegate: ComputerScreenDelegate) {
        self.texts = texts
        self.delegate = delegate
    }

    let timer = Timer.publish(every: 0.05, on: .main, in: .common).autoconnect()

    var body: some View {
        ZStack {
            VStack {
                Rectangle()
                    .fill(.black, strokeBorder: .secondary, lineWidth: 20)
                    .frame(width: 300, height: 300, alignment: .center)
                    .cornerRadius(10)
                    .overlay {
                        VStack {
                            HStack {
                                Text(displayedText)
                                    .fontWeight(.semibold)
                                    .font(.title3)
                                    .frame(alignment: .leading)
                                    .padding()
                                    .padding()
                                    .foregroundColor(.green)
                                Spacer()
                            }
                            Spacer()
                        }
                    }
                Rectangle()
                    .fill(.secondary, strokeBorder: .black, lineWidth: 0)
                    .frame(width: 300, height: 50, alignment: .center)
                    .cornerRadius(10)
                    .overlay {
                        HStack {
                            Rectangle()
                                .frame(maxWidth: .infinity, minHeight: 2, maxHeight: 2)
                                .foregroundColor(.primary)
                                .padding()
                            Circle()
                                .fill(.red, strokeBorder: .clear, lineWidth: 0)
                                .frame(width: 20, height: 20, alignment: .center)
                                .overlay(content: {
                                    Image(systemName: "power")
                                        .frame(width: 10, height: 10, alignment: .center)
                                        .foregroundColor(.white)
                                        .padding()
                                })
                                .onTapGesture {
                                    getNextText("I'm sorry, Player, I'm afraid I can't do that")
                                }
                            Circle()
                                .fill((displayingUnderscore ? .clear : .green), strokeBorder: .clear, lineWidth: 0)
                                .frame(width: 10, height: 10, alignment: .center)
                                .padding()
                        }
                    }
            }

        }
        .onReceive(timer) { _ in
            if finalTextIndex == -1 {
                getNextText()
            } else {
                digits += 1
                displayedText = String(finalText.prefix(digits)) + (displayingUnderscore ? "_" : "")
                ticksWithUnderscore += 1
                if ticksWithUnderscore == maxUnderscoreticks {
                    ticksWithUnderscore = 0
                    displayingUnderscore = !displayingUnderscore
                }
            }
        }
        .onTapGesture {
            getNextText { didFinish in
                didFinishText = didFinish
                if didFinishText {
                    delegate.didFinishDisplayingAllText()
                }
            }
        }
    }

    func getNextText(_ completion: @escaping ((Bool) -> Void) = { _ in return }) {
        finalTextIndex += 1
        if finalTextIndex < texts.count {
            synthesizer.speak(utteranceFrom(texts[finalTextIndex]))
            digits = 0
            finalText = texts[finalTextIndex]
            completion(false)
        } else {
            completion(true)
        }
    }

    func getNextText(_ string: String) {
        synthesizer.speak(utteranceFrom(string))
        digits = 0
        finalText = string
    }
}
