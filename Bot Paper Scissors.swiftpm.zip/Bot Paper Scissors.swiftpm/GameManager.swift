//
//  GameManager.swift
//  Bot Paper Scissors
//
//  Created by Erick Manaroulas Felipe on 20/04/22.
//

import Foundation

enum GameState: CaseIterable {
    case waiting
    case countdown
    case result
    case loading
}

class GameManager: ObservableObject {
    static let shared = GameManager()

    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var nextHandPoseToPlay: HandPose {
        return HandPose.validPoses.randomElement()!
    }

    @Published var currentlyReadHandPose: HandPose = .undefined
    @Published var currentlyDisplayedHandPose: HandPose = .undefined
    @Published var currentGameState: GameState = .loading
    @Published var welcomeText: String = ""
}
