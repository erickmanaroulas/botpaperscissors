//
//  StoryView.swift
//  Bot Paper Scissors
//
//  Created by Erick Manaroulas Felipe on 22/04/22.
//

import SwiftUI

struct StoryView: View, ComputerScreenDelegate {
    func didFinishDisplayingAllText() {
        didFinishText = true
    }

    @State var didFinishText: Bool = false

    var body: some View {
        VStack {
            ComputerScreenView(texts: ["My human eyes are not the same that they used to be.", "Would you be a dear and help me see your hands?", "Make the sign that. BEATS. The one displayed, try to mimic the emojis!", "Try to fill the screen with your human hand, and keep the position for a few seconds." ], delegate: self)
            HStack {
                Text("✊")
                    .font(.system(size: 100))
                Text("🖐")
                    .font(.system(size: 100))
                Text("✌️")
                    .font(.system(size: 100))
            }

            NavigationLink {
                CalibrationView()
            } label: {
                Image(systemName: "play.fill")
                    .foregroundColor(.primary)
                    .padding()
                    .padding(.horizontal, 100)
                    .background(Color.accentColor)
                    .cornerRadius(90)
            }.disabled(!didFinishText)
        }
        .navigationTitle("Calibration")
    }
}

struct StoryView_Previews: PreviewProvider {
    static var previews: some View {
        StoryView()
    }
}
