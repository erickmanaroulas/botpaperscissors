//
//  VictoryView.swift
//  Bot Paper Scissors
//
//  Created by Erick Manaroulas Felipe on 24/04/22.
//

import SwiftUI

struct VictoryView: View, ComputerScreenDelegate {
    func didFinishDisplayingAllText() {
        didFinishText = true
    }

    @State var didFinishText: Bool = false
    var body: some View {
        VStack {
            ComputerScreenView(texts: ["Oh no.", "I lost.", "My human emotions are overflowing with sadness :("], delegate: self)
            NavigationLink(destination: EndView(), isActive: $didFinishText, label: { Text("done") }).hidden()
        }
    }
}

struct VictoryView_Previews: PreviewProvider {
    static var previews: some View {
        VictoryView()
    }
}
