//
//  CameraViewController.swift
//  Bot Paper Scissors
//
//  Created by Erick Manaroulas Felipe on 18/04/22.
//

import UIKit
import AVFoundation
import Vision

final class CameraViewController: UIViewController {
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        UIApplication.shared.isIdleTimerDisabled = true
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        UIApplication.shared.isIdleTimerDisabled = true
    }

    private let handPoseRequest: VNDetectHumanHandPoseRequest = {
        let request = VNDetectHumanHandPoseRequest()
        request.maximumHandCount = 2
        request.revision = VNDetectHumanHandPoseRequestRevision1

        return request
    }()

    private let jokempoModel: Jokempo = {
        let model = Jokempo()

        return model
    }()

    var cameraFeedSession: AVCaptureSession?
    private var cameraView: CameraPreview { view as! CameraPreview }
    private let videoDataOutputQueue = DispatchQueue(
        label: "CameraFeedOutput",
        qos: .userInteractive
    )

    override func loadView() {
        view = CameraPreview()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        do {
            if cameraFeedSession == nil {
                try setupAVSession()
                cameraView.previewLayer.session = cameraFeedSession
                cameraView.previewLayer.videoGravity = .resizeAspectFill
            }
            cameraFeedSession?.startRunning()
        } catch {
            print(error.localizedDescription)
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        cameraFeedSession?.stopRunning()
        super.viewWillDisappear(animated)
    }

    func setupAVSession() throws {
        guard let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front)
        else {
            print("Could not find a front facing camera.")
            return
        }

        guard let deviceInput = try? AVCaptureDeviceInput(device: videoDevice)
        else {
            print("Could not create video device input.")
            return
        }

        let session = AVCaptureSession()
        session.beginConfiguration()
        session.sessionPreset = AVCaptureSession.Preset.high

        guard session.canAddInput(deviceInput) else {
            print("Could not add video device input to the session")
            return
        }
        
        session.addInput(deviceInput)

        let dataOutput = AVCaptureVideoDataOutput()
        if session.canAddOutput(dataOutput) {
            session.addOutput(dataOutput)
            dataOutput.alwaysDiscardsLateVideoFrames = true
            dataOutput.setSampleBufferDelegate(self, queue: videoDataOutputQueue)
        } else {
            print("Could not add video data output to the session")
            return
        }

        session.commitConfiguration()
        cameraFeedSession = session
    }

}

extension CameraViewController: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        DispatchQueue.global().async {
            let handler = VNImageRequestHandler(cmSampleBuffer: sampleBuffer, orientation: .up)

            do {
                connection.videoOrientation = .portrait
                try handler.perform([self.handPoseRequest])
                guard let handPoses = self.handPoseRequest.results, !handPoses.isEmpty else {
                    print("No handPoses found")
                    DispatchQueue.main.async {
                        GameManager.shared.currentlyReadHandPose = .undefined
                    }
                    return
                }

                let handObservation = handPoses.first

                guard let keypointsMultiArray = try? handObservation?.keypointsMultiArray() else {
                    print("No keypoints found in handPose")
                    DispatchQueue.main.async {
                        GameManager.shared.currentlyReadHandPose = .undefined
                    }
                    return
                }

                let handPosePrediction = try self.jokempoModel.prediction(poses: keypointsMultiArray)
                let confidence = handPosePrediction.labelProbabilities[handPosePrediction.label]!

                if confidence > 0.99 {
                    DispatchQueue.main.async {
                        print(handPosePrediction.label)
                        print(confidence)

                        if let translatedPose = HandPose.allCases.first(where: { pose in
                            handPosePrediction.label.lowercased().contains(pose.rawValue)
                        }) {
                            GameManager.shared.welcomeText = handPosePrediction.label
                            GameManager.shared.currentlyReadHandPose = translatedPose
                        } else {
                            GameManager.shared.currentlyReadHandPose = .undefined
                        }
                    }
                } else {
                    DispatchQueue.main.async {
                        GameManager.shared.currentlyReadHandPose = .undefined
                    }
                }
            } catch {
                print("Failure performing handPoseRequest")
                self.cameraFeedSession?.stopRunning()
            }
        }

    }
}
