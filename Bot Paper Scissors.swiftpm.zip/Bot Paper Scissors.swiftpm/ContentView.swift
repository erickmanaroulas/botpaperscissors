//
//  ContentView.swift
//  Bot Paper Scissors
//
//  Created by Erick Manaroulas Felipe on 20/04/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        CalibrationView()
    }
}
