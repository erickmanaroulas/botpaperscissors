//
//  CameraView.swift
//  Rps
//
//  Created by Erick Manaroulas Felipe on 18/04/22.
//

import SwiftUI

struct CameraView: UIViewControllerRepresentable {

    func makeUIViewController(context: Context) -> CameraViewController {
        let cvc = CameraViewController()
        return cvc
    }


    func updateUIViewController(_ uiViewController: CameraViewController,
                                context: Context) {

    }
}
