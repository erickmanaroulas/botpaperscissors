//
//  StartView.swift
//  Bot Paper Scissors
//
//  Created by Erick Manaroulas Felipe on 20/04/22.
//

import SwiftUI

struct StartView: View, ComputerScreenDelegate {
    func didFinishDisplayingAllText() {
        didFinishText = true
    }

    @State var personIsTakingLongToTap: Bool = false
    @State var didFinishText: Bool = false

    var body: some View {
            VStack {
                Spacer()
                ComputerScreenView(texts: ["Hello, fellow human.", "I would very much enjoy partaking in a totally fair Rock Paper Scissors game with you :)", "Would you like to play with me?"], delegate: self)
                    .onTapGesture {
                        personIsTakingLongToTap = false
                    }
                if personIsTakingLongToTap {
                    Text("Try tapping on the computer!")
                        .foregroundColor(.secondary)
                        .font(.title)
                }
                Spacer()
                if didFinishText {
                    VStack {
                        Text("Rock, Paper, Scissors!")
                            .font(.largeTitle)
                        Text("Machine Learning Edition")
                            .font(.headline)
                    }

                    NavigationLink {
                        StoryView()
                    } label: {
                        Image(systemName: "play.fill")
                            .foregroundColor(.primary)
                            .padding()
                            .padding(.horizontal, 100)
                            .background(Color.accentColor)
                            .cornerRadius(90)

                    }.disabled(!didFinishText)
                }

                Spacer()
            }
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 10) {
                    personIsTakingLongToTap = true
                }
            }
        }

}
