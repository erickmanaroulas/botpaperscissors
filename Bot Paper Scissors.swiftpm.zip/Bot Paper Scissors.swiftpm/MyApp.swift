import SwiftUI
import Foundation

@main
struct MyApp: App , ComputerScreenDelegate {
    func didFinishDisplayingAllText() {
        print("Finished displaying text")
    }

    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup {
            NavigationView {
                StartView()
            }.navigationViewStyle(.stack)
        }
    }
}

class AppDelegate: NSObject {
  static var orientationLock = UIInterfaceOrientationMask.portrait
}

extension AppDelegate: UIApplicationDelegate {

  func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
    return AppDelegate.orientationLock
  }
}
