//
//  EndView.swift
//  Bot Paper Scissors
//
//  Created by Erick Manaroulas Felipe on 24/04/22.
//

import SwiftUI

struct EndView: View, ComputerScreenDelegate {
    func didFinishDisplayingAllText() {
        didFinishText = true
    }

    @State var didFinishText: Bool = false
    
    var body: some View {
        ComputerScreenView(texts: ["Anyway, I'm happy to have someone to play with.", "Thanks for being my test subj...", "Thanks for being my friend"], delegate: self)
    }
}

struct EndView_Previews: PreviewProvider {
    static var previews: some View {
        EndView()
    }
}
