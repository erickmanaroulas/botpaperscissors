//
//  GameView.swift
//  Bot Paper Scissors
//
//  Created by Erick Manaroulas Felipe on 22/04/22.
//

import SwiftUI

struct GameView: View {
    @ObservedObject var gameManager = GameManager.shared

    let countdownWaitTime = 3

    @State var circleFillColor: Color = .white
    @State var centerDisplayText: String = "5"
    @State var timeLeft: Int = 3
    @State var wins: Int = 0
    @State var draws: Int = 0
    @State var losses: Int = 0

    @State var didWin = false
    @State var didLose = false

    var body: some View {
        ZStack {
            NavigationLink(destination: VictoryView(), isActive: $didWin, label: { Text("win") }).hidden()
            NavigationLink(destination: LossView(), isActive: $didLose, label: { Text("lose") }).hidden()
            VStack {
                Text("You are making a \(gameManager.currentlyReadHandPose.emoji)")
                    .padding()
                    .background(Color.primary.opacity(0.2))
                    .cornerRadius(30)
                    .frame(alignment: .topLeading)
                CameraView()
                    .padding()
                    .border(circleFillColor, width: 4)
                HStack {
                        Text("Wins: \(wins)")
                            .fontWeight(.semibold)
                            .font(.title3)
                        Text("Draws: \(draws)")
                            .fontWeight(.semibold)
                            .font(.title3)
                        Text("Losses: \(losses)")
                            .fontWeight(.semibold)
                            .font(.title3)
                    }
                .padding()
                .background(Color.primary.opacity(0.2))
                     .cornerRadius(30)
                     .frame(alignment: .topLeading)

            }
            ZStack {
                Circle()
                    .fill(circleFillColor, strokeBorder: .black, lineWidth: 5)
                    .frame(width: 200, height: 200, alignment: .center)
                    .onTapGesture {
                        switch gameManager.currentGameState {
                        case .result, .waiting:
                            gameManager.currentGameState = .countdown
                        default:
                            return
                        }
                    }
                VStack {
                    Text(centerDisplayText)
                        .fontWeight(.semibold)
                        .font(.largeTitle)
                        .foregroundColor(.black)
                        .onReceive(gameManager.timer) { input in
                            switch gameManager.currentGameState {
                            case .waiting:
                                return
                            case .countdown:
                                centerDisplayText = "\(timeLeft)"
                                if timeLeft == 0 {
                                    timeLeft = countdownWaitTime
                                    gameManager.currentGameState = .result
                                } else {
                                    timeLeft -= 1
                                }
                            default:
                                return
                            }
                        }
                        .onChange(of: gameManager.currentGameState) { newValue in
                            switch newValue {
                            case .waiting:
                                centerDisplayText = "Tap to play!"
                            case .countdown:
                                timeLeft = countdownWaitTime
                                circleFillColor = .white
                                centerDisplayText = "\(timeLeft)"
                            case .result:
                                gameManager.currentlyDisplayedHandPose = gameManager.nextHandPoseToPlay
                                let result = gameManager.currentlyReadHandPose.compare(other: gameManager.currentlyDisplayedHandPose)
                                centerDisplayText = gameManager.currentlyDisplayedHandPose.emoji

                                DispatchQueue.main.asyncAfter(deadline: .now() + 1){
                                    circleFillColor = result.color
                                    centerDisplayText = result.displayString

                                    switch result {
                                    case .victory:
                                        wins += 1
                                        if wins >= 3 {
                                            didWin = true
                                        }
                                    case .loss:
                                        losses += 1
                                        if losses >= 3 {
                                            didLose = true
                                        }
                                    case .draw:
                                        draws += 1
                                    case .undefined:
                                        break
                                    }

                                    DispatchQueue.main.asyncAfter(deadline: .now() + 1){
                                        gameManager.currentGameState = .countdown
                                    }
                                }
                            default:
                                return
                            }
                        }
                }
            }
        }.onAppear {
            gameManager.currentGameState = .waiting
            gameManager.currentlyDisplayedHandPose = .undefined

        }
    }
}

struct GameView_Previews: PreviewProvider {
    static var previews: some View {
        GameView()
    }
}
